package br.com.veloe.mock.integracoes.model;

public class Contato {

    private Nome nome;

    private ContatoEletronico email;

    public Nome getNome() {
        return nome;
    }

    public void setNome(Nome nome) {
        this.nome = nome;
    }

    public ContatoEletronico getEmail() {
        return email;
    }

    public void setEmail(ContatoEletronico email) {
        this.email = email;
    }

}
