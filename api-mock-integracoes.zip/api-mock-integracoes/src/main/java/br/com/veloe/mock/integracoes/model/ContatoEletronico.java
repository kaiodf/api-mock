package br.com.veloe.mock.integracoes.model;

public class ContatoEletronico {
    private String id;

    private String enderecoEletronico;

    private boolean newsletter;

    public ContatoEletronico(String id, String enderecoEletronico, Boolean news) {
        this.id = id;
        this.enderecoEletronico = enderecoEletronico;
        this.newsletter = news;
    }

    public ContatoEletronico(String id, String enderecoEletronico) {
        this.id = id;
        this.enderecoEletronico = enderecoEletronico;
    }

    public ContatoEletronico() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEnderecoEletronico() {
        return enderecoEletronico;
    }

    public void setEnderecoEletronico(String enderecoEletronico) {
        this.enderecoEletronico = enderecoEletronico;
    }

    public boolean isNewsletter() {
        return newsletter;
    }

    public void setNewsletter(boolean newsletter) {
        this.newsletter = newsletter;
    }
}