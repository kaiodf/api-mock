package br.com.veloe.mock.integracoes.model;

public class Endereco {
    private String cep;

    private String uf;

    private String cidade;

    private String bairro;

    private String logradouro;

    private String numero;

    private String complemento;

    private Boolean correspondencia;

    private Long codigo;

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public Boolean isCorrespondencia() {
        return correspondencia;
    }

    public void setCorrespondencia(Boolean correspondencia) {
        this.correspondencia = correspondencia;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Endereco [cep=");
        builder.append(cep);
        builder.append(", uf=");
        builder.append(uf);
        builder.append(", cidade=");
        builder.append(cidade);
        builder.append(", bairro=");
        builder.append(bairro);
        builder.append(", logradouro=");
        builder.append(logradouro);
        builder.append(", numero=");
        builder.append(numero);
        builder.append(", complemento=");
        builder.append(complemento);
        builder.append(", correspondencia=");
        builder.append(correspondencia);
        builder.append(", codigo=");
        builder.append(codigo);
        builder.append("]");
        return builder.toString();
    }

}