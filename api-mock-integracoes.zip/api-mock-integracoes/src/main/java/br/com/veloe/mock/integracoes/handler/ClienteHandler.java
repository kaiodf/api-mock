package br.com.veloe.mock.integracoes.handler;

import br.com.veloe.mock.integracoes.model.Cliente;
import com.amazonaws.serverless.proxy.internal.model.AwsProxyRequest;
import com.amazonaws.serverless.proxy.internal.model.AwsProxyResponse;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.util.json.Jackson;

import java.net.HttpURLConnection;

public class ClienteHandler implements RequestHandler<AwsProxyRequest, AwsProxyResponse> {

    public AwsProxyResponse handleRequest(AwsProxyRequest input, Context context) {
//       TODO: Chamar mock
        Cliente cliente = new Cliente();

        AwsProxyResponse response = new AwsProxyResponse(HttpURLConnection.HTTP_OK);
        response.setBody(Jackson.toJsonString(cliente));

        return response;
    }
}
