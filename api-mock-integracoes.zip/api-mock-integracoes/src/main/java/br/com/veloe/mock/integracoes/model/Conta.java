package br.com.veloe.mock.integracoes.model;

public class Conta {
    private String produto;

    private String saldo;

    private String plano;

    private String conta;

    private String status;

    private Boolean temMensalidade;

    private String saldoMinRecarga;

    private String tipoRecarga;

    private String tipo;

    private String formaPagamento;

    private String dataAdesao;

    private String limite;

    private String saldoDisponivel;

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public String getSaldo() {
        return saldo;
    }

    public void setSaldo(String saldo) {
        this.saldo = saldo;
    }

    public String getPlano() {
        return plano;
    }

    public void setPlano(String plano) {
        this.plano = plano;
    }

    public String getConta() {
        return conta;
    }

    public void setConta(String conta) {
        this.conta = conta;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Boolean getTemMensalidade() {
        return temMensalidade;
    }

    public void setTemMensalidade(Boolean temMensalidade) {
        this.temMensalidade = temMensalidade;
    }

    public String getSaldoMinRecarga() {
        return saldoMinRecarga;
    }

    public void setSaldoMinRecarga(String saldoMinRecarga) {
        this.saldoMinRecarga = saldoMinRecarga;
    }

    public String getTipoRecarga() {
        return tipoRecarga;
    }

    public void setTipoRecarga(String tipoRecarga) {
        this.tipoRecarga = tipoRecarga;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public String getLimite() {
        return limite;
    }

    public void setLimite(String limite) {
        this.limite = limite;
    }

    public String getDataAdesao() {
        return dataAdesao;
    }

    public void setDataAdesao(String dataAdesao) {
        this.dataAdesao = dataAdesao;
    }

    public String getSaldoDisponivel() {
        return saldoDisponivel;
    }

    public void setSaldoDisponivel(String saldoDisponivel) {
        this.saldoDisponivel = saldoDisponivel;
    }
}
