package br.com.veloe.mock.integracoes.handler;

import br.com.veloe.mock.integracoes.model.Conta;
import com.amazonaws.serverless.proxy.internal.model.AwsProxyRequest;
import com.amazonaws.serverless.proxy.internal.model.AwsProxyResponse;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.util.json.Jackson;

import java.net.HttpURLConnection;

public class ContaHandler  implements RequestHandler<AwsProxyRequest, AwsProxyResponse> {

    @Override
    public AwsProxyResponse handleRequest(AwsProxyRequest input, Context context) {
        Conta conta = new Conta();
        AwsProxyResponse response = new AwsProxyResponse(HttpURLConnection.HTTP_OK);
        response.setBody(Jackson.toJsonString(conta));

        return response;
    }
}
