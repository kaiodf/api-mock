package br.com.veloe.mock.integracoes.model;

import java.util.List;

public class Cliente {

    private Integer id;

    private String customerId;

//    private UserType type;

    private String nome;

    private String nomeFantasia;

    private String razaoSocial;

    private String cpf;

    private String cnpj;

    private Contato contato;

    private Contato contatoAdministrador;

    private List<Endereco> enderecos;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

//    public UserType getType() {
//        return type;
//    }
//
//    public void setType(UserType type) {
//        this.type = type;
//    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nome = nomeFantasia;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public List<Endereco> getEnderecos() {
        return enderecos;
    }

    public void setEnderecos(List<Endereco> enderecos) {
        this.enderecos = enderecos;
    }

    public Contato getContato() {
        return contato;
    }

    public Contato getContatoAdministrador() {
        return contatoAdministrador;
    }

    public void setContatoAdministrador(Contato contatoAdministrador) {
        this.contatoAdministrador = contatoAdministrador;
    }

    public void setContato(Contato contato) {
        this.contato = contato;
    }

    public Endereco getEnderecoPrincipal() {
        Endereco endereco = null;

        if (this.enderecos != null && !this.enderecos.isEmpty()) {
            endereco = this.enderecos.stream().filter(Endereco::isCorrespondencia).findFirst().orElse(null);
        }

        return endereco;
    }

    public Endereco getEnderecoCorrespondencia() {
        Endereco endereco = null;

        if (this.enderecos != null && !this.enderecos.isEmpty()) {
            endereco = this.enderecos.stream().filter(Endereco::isCorrespondencia).findFirst().orElse(null);
        }

        return endereco;
    }

    @Override
    public String toString() {
        return "Cliente [id=" + id + ", customerId=" + customerId + ", nome=" + nome
                + ", nomeFantasia=" + nomeFantasia + ", razaoSocial=" + razaoSocial + ", cpf=" + cpf
                + ", cnpj=" + cnpj + ", contato=" + contato + ", enderecos=" + enderecos + "]";
    }
}